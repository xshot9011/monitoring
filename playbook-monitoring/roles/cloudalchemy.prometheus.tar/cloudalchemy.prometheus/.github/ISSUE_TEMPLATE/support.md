---
name: Support
about: If you have questions about this ansible role
labels: question
---

**What did you do?**

**Did you expect to see some different?**

**Environment**

* Role version:

    `Insert release version/galaxy tag or Git SHA here`

* Ansible version information:

    `ansible --version`
    <!-- Replace the command with its output above -->

* Variables:

```
insert role variables relevant to the issue
```

* Ansible playbook execution Logs:

```
insert Ansible logs relevant to the issue here
```

**Anything else we need to know?**:
